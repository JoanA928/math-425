Party coding update for seat-merged U.S. Senate vote database, 1990-2026
D / Voteview party code 100 = 1
R / Voteview party code 200 = -1
Independent and all other affiliations = 0
Slash-separated within-year seat transitions are preserved chronologically (for example D/R becomes 1/-1).
Vote coding and all other fields are unchanged from the seat-merged database.
