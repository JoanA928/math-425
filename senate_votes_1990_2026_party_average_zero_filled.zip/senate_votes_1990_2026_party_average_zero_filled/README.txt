US Senate vote matrices, 1990-present, merged by Senate seat within each calendar year.
If a seat changes occupants during a year, last_name is slash-joined in chronological order (example: Clinton/Gillibrand).
party is likewise slash-joined only when affiliation changes across occupants.
Vote coding: Yea=1, Nay=-1, Present/Not Voting=0, blank=no occupant vote for that seat on that roll call.
Seat lineages were inferred from non-overlapping/overlapping service intervals in the Voteview Senate vote data; each state is constrained to two seat lineages.
