Senate votes 1990-2026, seat-merged, numeric/averaged party affiliation, with all blank vote cells filled with 0.
Vote coding: Yea=1, Nay=-1, Present/Not Voting/previously blank=0.
Party coding: D=1, R=-1, other=0; within-year seat transitions use arithmetic mean of occupant party codes.
