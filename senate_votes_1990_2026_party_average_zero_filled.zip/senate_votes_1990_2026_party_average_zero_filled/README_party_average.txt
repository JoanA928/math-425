Party coding: Democrat=1, Republican=-1, Independent/other=0.
For a within-year seat transition with multiple occupants, party is the simple arithmetic mean of each occupant party code.
Examples: D/R = 0; D/I = 0.5; R/I = -0.5; D/D = 1.
